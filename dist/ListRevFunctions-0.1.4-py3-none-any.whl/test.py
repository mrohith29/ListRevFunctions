import ListOperations as lo

a = [1,2,3]
b = [4,5,6]

ob = lo.perform(a,b)
print(ob.add())