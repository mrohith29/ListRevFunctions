# ListRevFunctions

Using this package you can perform opertions on two lists with second list reversed.